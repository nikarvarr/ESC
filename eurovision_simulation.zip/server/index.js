
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost/eurovision', { useNewUrlParser: true, useUnifiedTopology: true });

const Country = require('./models/country');

app.get('/countries', async (req, res) => {
  const countries = await Country.find();
  res.json(countries);
});

app.post('/qualify', async (req, res) => {
  const { countryNames } = req.body;
  await Country.updateMany({ name: { $in: countryNames } }, { qualified: true });
  res.json({ message: 'Countries qualified' });
});

app.listen(port, () => {
  console.log(`Server is running on port: ${port}`);
});
    