
const mongoose = require('mongoose');
const Country = require('../models/country');

const countries = [
  'Albania', 'Armenia', 'Australia', 'Austria', 'Azerbaijan', 'Belarus', 'Belgium',
  'Croatia', 'Cyprus', 'Czech Republic', 'Denmark', 'Estonia', 'Finland', 'France',
  'Germany', 'Greece', 'Hungary', 'Iceland', 'Ireland', 'Israel', 'Italy',
  'Latvia', 'Lithuania', 'Malta', 'Moldova', 'Netherlands', 'Norway', 'Poland',
  'Portugal', 'Romania', 'Russia', 'San Marino', 'Serbia', 'Slovakia', 'Slovenia',
  'Spain', 'Sweden', 'Switzerland', 'Ukraine', 'United Kingdom'
];

const seedDatabase = async () => {
  await mongoose.connect('mongodb://localhost/eurovision', { useNewUrlParser: true, useUnifiedTopology: true });
  await Country.deleteMany({});
  for (let countryName of countries) {
    const country = new Country({ name: countryName, qualified: false });
    await country.save();
  }
  mongoose.disconnect();
};

seedDatabase();
    