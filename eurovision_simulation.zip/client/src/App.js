
import React, { useEffect, useState } from 'react';
import './App.css';

const App = () => {
  const [countries, setCountries] = useState([]);
  const [selectedCountries, setSelectedCountries] = useState([]);

  useEffect(() => {
    fetch('http://localhost:5000/countries')
      .then(response => response.json())
      .then(data => setCountries(data));
  }, []);

  const handleCountrySelect = (country) => {
    setSelectedCountries(prev => {
      if (prev.includes(country)) {
        return prev.filter(c => c !== country);
      } else {
        return [...prev, country];
      }
    });
  };

  const handleQualify = () => {
    fetch('http://localhost:5000/qualify', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ countryNames: selectedCountries }),
    })
      .then(response => response.json())
      .then(data => {
        console.log(data.message);
        setSelectedCountries([]);
      });
  };

  return (
    <div>
      <h1>Eurovision 2024 Simulation</h1>
      <div>
        {countries.map(country => (
          <div key={country._id}>
            <input
              type="checkbox"
              checked={selectedCountries.includes(country.name)}
              onChange={() => handleCountrySelect(country.name)}
            />
            {country.name}
          </div>
        ))}
      </div>
      <button onClick={handleQualify}>Qualify Selected Countries</button>
    </div>
  );
};

export default App;
    